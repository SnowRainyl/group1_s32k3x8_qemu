// hw/arm/s32k3x8evb.h
#ifndef HW_ARM_S32K3X8EVB_H
#define HW_ARM_S32K3X8EVB_H

#include "qemu/osdep.h"
#include "qemu/units.h"
#include "qom/object.h"
#include "hw/boards.h"
#include "hw/arm/armv7m.h"
#include "hw/sysbus.h"

// 定义内存大小
#define S32K3X8EVB_FLASH_SIZE (4 * MiB)  
#define S32K3X8EVB_SRAM_SIZE  (1 * MiB)
//define the size of memory--mapping
#define S32K3_SRAM0_BASE     0x40264000  /* PRAMC_0 */
#define S32K3_FLASH_BASE     0x00400000  /* FLASH */


// 定义设备类型标识符
#define TYPE_S32K3X8EVB_MACHINE "s32k3x8evb"

// 板级状态结构体
typedef struct S32K3X8EVBState {
    MachineState parent_obj;
    
    // Cortex-M7 CPU
    ARMv7MState armv7m;
    
    // Memory regions
    MemoryRegion flash;
    MemoryRegion sram;
    
    // Peripherals 
    DeviceState *uart;
    DeviceState *spi;
} S32K3X8EVBState;

// 声明状态检查宏
DECLARE_INSTANCE_CHECKER(S32K3X8EVBState, S32K3X8EVB_MACHINE, 
                        TYPE_S32K3X8EVB_MACHINE)

#endif
