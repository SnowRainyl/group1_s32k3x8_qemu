// hw/arm/s32k3x8evb.c
//(1)Contains basic system dependencies (操作系统依赖) and common functions that QEMU needs to work on different operating systems
#include "qemu/osdep.h"
//(2)log and error/errors report in clean way
#include "qemu/log.h"
#include "qemu/error-report.h"
#include "qapi/error.h"
#include "exec/memory.h"
#include "exec/address-spaces.h"
#include "sysemu/sysemu.h"
//(3)we define
#include "hw/arm/s32k3x8evb.h"
#include "hw/char/s32k3x8_uart.h"
//(4)Handles the boot process (启动过程) for ARM systems,Helps QEMU start up ARM machines correctly
#include "hw/arm/boot.h"

//(5)Manages device properties (设备属性)
//Helps set up and control virtual hardware features
#include "hw/qdev-properties.h"

//(6)Handles clock signals and timing for virtual devices
//Controls how fast different parts of the system run
#include "hw/qdev-clock.h"

#include <stdio.h>
// 板级初始化函数
static void s32k3x8evb_init(MachineState *machine)
{
	//tansfer a normal machine(qemu provides) to specific machine(S32K3X8EVB) that we can use some specific functions in this specific board
    //S32K3X8EVBState==>s32k3x8evb.h
    //S32K3X8EVB_MACHINE==>>s32k3x8evb.h==>DECLARE_INSTANCE_CHECKER()==>qemu/include/qom/object.h
	
	S32K3X8EVBState *s = S32K3X8EVB_MACHINE(machine);
    //initial state of error, if the next steps occur some error, it can record errors.
    Error *err = NULL;


    // 初始化 Cortex-M7 CPU
    object_initialize_child(OBJECT(machine), "armv7m", &s->armv7m,
                          TYPE_ARMV7M);
    qdev_prop_set_string(DEVICE(&s->armv7m), "cpu-type", 
                        ARM_CPU_TYPE_NAME("cortex-m7"));
    sysbus_realize(SYS_BUS_DEVICE(&s->armv7m), &error_abort);

    
    
    
    // 初始化内存区域
    memory_region_init_rom(&s->flash, OBJECT(machine), "s32k3x8evb.flash",
                          S32K3X8EVB_FLASH_SIZE, &err);
    if (err) {
        error_report_err(err);
        return;
    }
    
    memory_region_init_ram(&s->sram, OBJECT(machine), "s32k3x8evb.sram",
                          S32K3X8EVB_SRAM_SIZE, &err);
    if (err) {
        error_report_err(err);
        return;
    }

    // 映射内存区域
    memory_region_add_subregion(get_system_memory(),S32K3_FLASH_BASE , &s->flash);
    memory_region_add_subregion(get_system_memory(),S32K3_SRAM0_BASE, &s->sram);

    // 初始化 UART
    s->uart = qdev_new(TYPE_S32K3X8_LPUART);
    sysbus_realize_and_unref(SYS_BUS_DEVICE(s->uart), &error_fatal);

    // 映射 UART 寄存器到内存空间
    sysbus_mmio_map(SYS_BUS_DEVICE(s->uart), 0, 0x40000000);

    // 初始化 SPI
   // s->spi = qdev_new(TYPE_S32K3X8_SPI);
   // sysbus_realize_and_unref(SYS_BUS_DEVICE(s->spi), &error_fatal);
    // 映射 SPI 寄存器到内存空间
   // sysbus_mmio_map(SYS_BUS_DEVICE(s->spi), 0, 0x40002000);

    // 加载固件(如果提供)
   // if (machine->firmware) {
     //   arm_load_kernel(ARM_CPU(first_cpu), machine, &s->flash, 
     //                  machine->firmware);
    //}




}

// 机器类初始化
static void s32k3x8evb_class_init(ObjectClass *oc, void *data)
{
    MachineClass *mc = MACHINE_CLASS(oc);

    mc->desc = "NXP S32K3X8EVB Development Board (Cortex-M7)"; 
    mc->init = s32k3x8evb_init;
    mc->default_cpus = 1;
   // mc->min_cpus = 1;
   // mc->max_cpus = 1;
    //mc->no_sdcard = 1;
    //mc->no_floppy = 1;
   // mc->no_cdrom = 1;
  //  mc->no_parallel = 1;
}

// 注册机器类型
static const TypeInfo s32k3x8evb_type = {
    .name = MACHINE_TYPE_NAME("s32k3x8evb"),
    .parent = TYPE_MACHINE,
    .instance_size = sizeof(S32K3X8EVBState),
    .class_init = s32k3x8evb_class_init,
};

static void s32k3x8evb_machine_init(void)
{
   	printf("hello\n");
	type_register_static(&s32k3x8evb_type);
	printf("Registration complete\n");
}

type_init(s32k3x8evb_machine_init)
