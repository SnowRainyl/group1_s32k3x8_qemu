/*
 * Copyright 2023-2024 NXP
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "S32K358.h"
#include "sys.h"
#include "core_cm7.h"

/* Including FreeMASTER Driver */
#include "freemaster.h"
#include "freemaster_s32_lpuart.h"

/* Including FreeMASTER example application */
#include "freemaster_example.h"

#if defined(__ghs__)
#define __INTERRUPT_SVC __interrupt
#define __ASM_VOLATILE __asm volatile
#define __NO_RETURN__ _Pragma("ghs nowarning 111")
#elif defined(__ICCARM__)
#define __INTERRUPT_SVC __svc
#define __ASM_VOLATILE asm volatile
#define __NO_RETURN__ _Pragma("diag_suppress=Pe111")
#elif defined(__DCC__)
#define __INTERRUPT_SVC __attribute__((interrupt("SWI")))
#define __ASM_VOLATILE __asm volatile
#define __NO_RETURN__
#elif defined(__GNUC__)
#define __INTERRUPT_SVC __attribute__((interrupt("SVC")))
#define __ASM_VOLATILE __asm volatile
#define __NO_RETURN__
#else
#define __INTERRUPT_SVC
#define __NO_RETURN__
#define __ASM_VOLATILE __asm volatile
#endif

uart_cfg_t uart_cfg = {
    (uart_pin_cfg_t)UART_PIN_CFG,
    AIPS_SLOW_CLK_FREQ,
    UART_BAUDREATE,
    UART_STOP_BITS,
    UART_PARITY,
    UART_DWIDTH};

int main(void)
{
    /* Configures clocks. (Check RM to see specific clock configurations) */
    int8_t error = sys_cfg_clock_opt(SYS_CLOCK_OPT_D);

    if (error)
        return 1;

    /* Checks if PLL is turned on, if not uses 24MHZ in AIPS SLOW instead */
    uart_cfg.clk_freq = sys_get_clock(SYS_CLK_AIPS_PLAT);

    /* Configure uart */
    uart_init(IP_LPUART_6, &uart_cfg, true);

    /* Set FreeMASTER serial base address */
    FMSTR_SerialSetBaseAddress((FMSTR_ADDR)IP_LPUART_6_BASE);

#if (FMSTR_LONG_INTR) || (FMSTR_SHORT_INTR)
    /* Enable interrupts */
    NVIC_SetPriority(LPUART6_IRQn, 2);
    NVIC_EnableIRQ(LPUART6_IRQn);
#endif

    /* Initialize FreeMASTER */
    FMSTR_Example_Init();

    for (;;)
    {
        FMSTR_Example_Poll();
    }
    /* to avoid the warning message for GHS and IAR: statement is unreachable */
    __NO_RETURN__
    return 0;
}

void LPUART6_Handler(void)
{
    FMSTR_SerialIsr();
}
