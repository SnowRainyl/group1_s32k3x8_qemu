/*
 * Copyright 2023-2024 NXP
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
#ifndef APP_INC_SYS_H_
#define APP_INC_SYS_H_

#include "clock/clock.h"
#include "uart/uart.h"

/* UART */
#define UART_INSTANCE	6
#define UART_TX_GPIO	16
#define UART_RX_GPIO 	15
#define UART_TX_SSS		0x05
#define UART_RX_SSS		0x02

#define UART_PIN_CFG {UART_INSTANCE, \
	UART_TX_GPIO,	\
	UART_TX_SSS,	\
	UART_RX_GPIO,	\
	UART_RX_SSS}

#define AIPS_SLOW_CLK_FREQ 	60000000
#define	UART_BAUDREATE 		115200
#define	UART_STOP_BITS 		UART_1_STOP_BIT
#define	UART_PARITY 		NO_PARITY
#define	UART_DWIDTH 		UART_DW_8_BITS

#define SYS_FXOSC_FREQ 16000000

typedef enum
{
	SYS_CLK_CORE,
	SYS_CLK_AIPS_PLAT,
	SYS_CLK_AIPS_SLOW,
	SYS_CLK_HSE,
	SYS_CLK_DCM,
	SYS_CLK_LBIST,
	SYS_CLK_QSPI,
#ifdef S32K388
	SYS_CLK_CM7_CORE
#endif
}sys_clk_e;

typedef enum
{
#ifdef S32K388
	SYS_CLOCK_OPT_A_PLUS_PLUS,
#endif
	SYS_CLOCK_OPT_A_PLUS,
	SYS_CLOCK_OPT_A,
	SYS_CLOCK_OPT_B,
	SYS_CLOCK_OPT_C,
	SYS_CLOCK_OPT_D,
	SYS_CLOCK_OPT_E,
	SYS_CLOCK_OPT_F
} sys_clk_opt_e;

typedef enum
{
#ifndef S32K388
	SYS_PMC_V15_BJT,
#endif
	SYS_PMC_V15_SMPS,
	SYS_PMC_V15_SBC
} sys_pmc_opt;

int8_t sys_cfg_clock_opt(sys_clk_opt_e opt);

uint32_t sys_get_clock(sys_clk_e sys_clk);

#endif /* APP_INC_SYS_H_ */
