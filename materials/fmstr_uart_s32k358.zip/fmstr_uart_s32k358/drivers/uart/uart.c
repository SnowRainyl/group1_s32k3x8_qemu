/*
 * Copyright 2023-2024 NXP
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
#include "uart.h"

#define MC_ME_LPUART_LOW_MASK	0x0003FC00
#define MC_ME_LPUART_HIGH_MASK	0x000007F8

#define UART_PROCESS_TIMEOUT	100000

static void uart_init_clock(void)
{
	IP_MC_ME->PRTN1_COFB2_CLKEN |= MC_ME_LPUART_LOW_MASK;
	IP_MC_ME->PRTN2_COFB1_CLKEN |= MC_ME_LPUART_HIGH_MASK;

	IP_MC_ME->PRTN1_PCONF |= MC_ME_PRTN0_PCONF_PCE_MASK;
	IP_MC_ME->PRTN1_PUPD  |= MC_ME_PRTN0_PUPD_PCUD_MASK;

	IP_MC_ME->PRTN2_PCONF |= MC_ME_PRTN1_PCONF_PCE_MASK;
	IP_MC_ME->PRTN2_PUPD  |= MC_ME_PRTN1_PUPD_PCUD_MASK;

	IP_MC_ME->CTL_KEY = 0x5AF0;
	IP_MC_ME->CTL_KEY = 0xA50F;

	/*Waits until Update process is finished*/
	while(IP_MC_ME->PRTN1_PUPD & MC_ME_PRTN0_PUPD_PCUD_MASK);
	while(IP_MC_ME->PRTN2_PUPD & MC_ME_PRTN1_PUPD_PCUD_MASK);

	while(!(IP_MC_ME->PRTN1_STAT & MC_ME_PRTN0_STAT_PCS_MASK));
	while(!(IP_MC_ME->PRTN2_STAT & MC_ME_PRTN1_STAT_PCS_MASK));
}

static void uart_init_pins (uart_pin_cfg_t * pin_cfg)
{
	/*TX pin config*/
	IP_SIUL2->MSCR[pin_cfg->tx_gpio] |= SIUL2_MSCR_OBE(1) | (pin_cfg->tx_sss << SIUL2_MSCR_SSS_0_SHIFT);

	/*RX pin configuration*/
	IP_SIUL2->MSCR[pin_cfg->rx_gpio] |= SIUL2_MSCR_IBE(1) | SIUL2_MSCR_PUE(1) | SIUL2_MSCR_PUS(1);
	IP_SIUL2->IMCR[(IMCR_LPUART0_RX - IMCR_OFFSET) + pin_cfg->uart_n] |= pin_cfg->rx_sss;
}

static void uart_send_dat(volatile LPUART_Type *module, int dat, uint16_t bit_msk)
{
	module -> DATA = dat & bit_msk & 0x03FF;
	while(!(module->STAT & LPUART_STAT_TC_MASK));
}

int8_t uart_get_dat(volatile LPUART_Type *module, int * byte, uint16_t bit_msk)
{
	uint32_t timeout = UART_PROCESS_TIMEOUT;
	uint8_t test = 0;
	while(((module->FIFO & LPUART_FIFO_RXEMPT_MASK) != 0) && (--timeout != 0) && ((module->STAT & LPUART_STAT_OR_MASK) == 0))
	module->STAT |= LPUART_STAT_OR_MASK;
	if(timeout == 0)
	{
		return -1;
	}
	else
	{
		test = module -> DATA & bit_msk;
		*byte = test;
		return 0;
	}
}

void uart_init(volatile LPUART_Type *module, uart_cfg_t *cfg, bool cfg_pins)
{
	uart_init_clock();
	if(cfg_pins)
	{
		uart_init_pins(&cfg->pin_cfg);
	}

	uint8_t osr = (module->BAUD & LPUART_BAUD_OSR_MASK) >> LPUART_BAUD_OSR_SHIFT;
	uint16_t sbr = cfg->clk_freq / ((osr + 1) * cfg->baudrate);

	uint32_t baud = LPUART_BAUD_SBR(sbr) | LPUART_BAUD_SBNS(cfg->stop_bits);
	baud &= ~LPUART_BAUD_OSR_MASK;
	baud |= LPUART_BAUD_OSR(osr);
	baud |= LPUART_BAUD_M10((cfg->d_width == 10) ? 1 : 0);

	module->BAUD = baud;

	module->FIFO |= LPUART_FIFO_RXFE_MASK;

	module->CTRL |= LPUART_CTRL_M7((cfg->d_width == 7) ? 1 : 0);
	module->CTRL |= LPUART_CTRL_M((cfg->d_width == 9) ? 1 : 0);

	module->CTRL |= (uint32_t) cfg->parity;

	module->CTRL |= LPUART_CTRL_TE_MASK | LPUART_CTRL_RE_MASK;
}

void uart_send_byte(volatile LPUART_Type *module, char byte)
{
	module -> DATA = byte;
	while(!(module->STAT & LPUART_STAT_TC_MASK));
}

void uart_put_string(volatile LPUART_Type *module, const char * str, uint16_t size)
{
	const char * str_buff = str;
	for(uint16_t i = 0; i < size; i++)
	{
		while (!(module->STAT & LPUART_STAT_TDRE_MASK));
		uart_send_byte(module,*str_buff);
		while(!(module->STAT & LPUART_STAT_TC_MASK));
		str_buff++;
	}
}

void uart_put_data(volatile LPUART_Type *module, int * str, uint16_t bit_msk, uint16_t size)
{
	int * str_buff = str;
	for(uint16_t i = 0; i < size; i++)
	{
		uart_send_dat(module,*str_buff, bit_msk);
		str_buff++;
	}
}

int8_t uart_read_string(volatile LPUART_Type *module, char * str, uint16_t size)
{
	char * str_buff = str;
	uint16_t i = 0;
	for(i = 0; i < size; i++)
	{
		if(uart_get_dat(module,(int *)str_buff,0x00FF))
		{
			break;
		}
		str_buff++;
	}

	if(i != size)
	{
		return -1;
	}
	else
	{
		return 0;
	}
}

int8_t uart_read_data(volatile LPUART_Type *module, int * str, uint16_t bit_msk, uint16_t size)
{
	int * str_buff = str;
	uint16_t i = 0;
	for(i = 0; i < size; i++)
	{
		if(uart_get_dat(module,str_buff,bit_msk))
		{
			break;
		}
		str_buff++;
	}

	if(i != size)
	{
		return -1;
	}
	else
	{
		return 0;
	}
}
