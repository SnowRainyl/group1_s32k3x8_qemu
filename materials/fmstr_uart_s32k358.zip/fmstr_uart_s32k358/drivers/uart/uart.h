/*
 * Copyright 2023-2024 NXP
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
#ifndef DRIVERS_UART_UART_H_
#define DRIVERS_UART_UART_H_

#include <stdbool.h>
#include "S32K358.h"

#define IMCR_LPUART0_RX 699
#define IMCR_OFFSET 512

#define UART_1_STOP_BIT	0
#define UART_2_STOP_BIT	1

#define UART_DW_7_BITS 7
#define UART_DW_8_BITS 8
#define UART_DW_9_BITS 9
#define UART_DW_10_BITS 10

/*Interrupt Flags*/
#define UART_LB_INT_FLG		LPUART_STAT_LBKDIF_MASK		/*LIN Break Detect Interrupt Flag*/
#define UART_REDGE_INT_FLG	LPUART_STAT_RXEDGIF_MASK	/*RXD Pin Active Edge Interrupt Flag*/
#define UART_IDLE_INT_FLG	LPUART_STAT_IDLE_MASK		/*IDLE Line FLag*/
#define UART_OVR_INT_FLG	LPUART_STAT_OR_MASK			/*Receiver Overrun Flag*/
#define UART_NOISE_INT_FLG	LPUART_STAT_NF_MASK			/*Noise Flag*/
#define UART_FRM_INT_FLG	LPUART_STAT_FE_MASK			/*Framing Error*/
#define UART_PARE_INT_FLG	LPUART_STAT_PF_MASK			/*Parity Error Flag*/
#define UART_TX_INT_FLG		LPUART_STAT_TC_MASK			/*Transmit Complete Flag*/
#define UART_MA1_INT_FLG	LPUART_STAT_MA1F_MASK		/*Match1 Flag*/
#define UART_MA2_INT_FLG	LPUART_STAT_MA2F_MASK		/*Match2 Flag*/

/*Interrupt mask*/
#define UART_LB_INT_MSK		0						/*LIN Break Detect Interrupt Flag*/
#define UART_REDGE_INT_MSK	1						/*RXD Pin Active Edge Interrupt Flag*/
#define UART_IDLE_INT_MSK	LPUART_CTRL_ILIE_MASK	/*IDLE Line FLag*/
#define UART_OVR_INT_MSK	LPUART_CTRL_ORIE_MASK	/*Receiver Overrun Flag*/
#define UART_NOISE_INT_MSK  LPUART_CTRL_NEIE_MASK	/*Noise Flag*/
#define UART_FRM_INT_MSK	LPUART_CTRL_FEIE_MASK	/*Framing Error*/
#define UART_PARE_INT_MSK	LPUART_CTRL_PEIE_MASK	/*Parity Error Flag*/
#define UART_TX_INT_MSK		LPUART_CTRL_TCIE_MASK	/*Transmit Complete Flag*/
#define UART_MA1_INT_MSK	LPUART_CTRL_MA1IE_MASK	/*Match1 Flag*/
#define UART_MA2_INT_MSK	LPUART_CTRL_MA2IE_MASK	/*Match2 Flag*/

/*Structure for pin configuration*/
typedef struct uart_pin_cfg
{
	uint8_t uart_n; 	/*UART instance for pin configuration*/
	uint16_t tx_gpio; 	/*GPIO number for TX*/
	uint16_t tx_sss;	/*SIUL selector for TX pin*/
	uint16_t rx_gpio;	/*GPIO number for RX*/
	uint16_t rx_sss;	/*SIUL selector for RX pin*/
} uart_pin_cfg_t;

/*Parity type for UART configuration*/
typedef enum uart_parity
{
	NO_PARITY = 0, 	/*No parity check in frame*/
	RESERVED,	   	/*RESERVED*/
	EVEN_PARITY,	/*Parity check enabled. Parity EVEN*/
	ODD_PARITY		/*Parity check enabled, Parity ODD*/
} uart_parity_e;

/*UART configuration structure*/
typedef struct uart_cfg
{
	uart_pin_cfg_t pin_cfg;	/*GPIO configuration structure pointer*/
	uint32_t clk_freq;			/*Clock frequency reference for baudrate calculation*/
	uint32_t baudrate;			/*Desired baudrate*/
	uint8_t	stop_bits		:1; /*Number of stop bits. 0: 1 stop bit. 1: 2 stop bits*/
	uart_parity_e parity	:2; /*Parity check. one of @ref uart_parity_e */
	uint8_t d_width			:4;	/*Data width (7-10 bits). If set other data width will be set to 8*/
} uart_cfg_t;

/*
 * uart_init
 * @brief	Initializes the LPUART instance
 * @param	Pointer to LPUART module
 * @param	UART config structure
 * */
void uart_init(volatile LPUART_Type *module, uart_cfg_t *cfg, bool cfg_pins);

/*
 * uart_put_string
 * @brief	Sends a single byte through the UART interface
 * @param	Pointer to LPUART module
 * @param	byte to be sent
 * */
void uart_send_byte(volatile LPUART_Type *module, char byte);

/*
 * uart_put_string
 * @brief	Sends a string through the UART interface
 * @param	Pointer to LPUART module
 * @param	Pointer to the string
 * @param	Size of data to be sent in bytes
 * */
void uart_put_string(volatile LPUART_Type *module, const char * str, uint16_t size);

/*
 * uart_put_data
 * @brief	Sends an array of data (7-10 bits) through the UART interface
 * @param	Pointer to LPUART module
 * @param	Pointer to the array
 * @param	Bitmask according to the data size (7-10 bits)
 * @param	Size of data to be sent in bytes
 * */
void uart_put_data(volatile LPUART_Type *module, int * str, uint16_t bit_msk, uint16_t size);

/*
 * uart_read_string
 * @brief	Read de Rx Buffer and stores it on a 8-bit array
 * @param	Pointer to LPUART module
 * @param	Pointer to the array
 * @param	Size of data to be read in bytes
 * @return	Returns -1 if could not read buffer, otherwise return 0
 * */
int8_t uart_read_string(volatile LPUART_Type *module, char * str, uint16_t size);

/*
 * uart_read_data
 * @brief	Read de Rx Buffer and stores it on a 16-bit array
 * @param	Pointer to LPUART module
 * @param	Pointer to the array
 * @param	Bitmask according to the data size (7-10 bits)
 * @param	Size of data to be read in bytes
 * @return	Returns -1 if could not read buffer, otherwise return 0
 * */
int8_t uart_read_data(volatile LPUART_Type *module, int * str, uint16_t bit_msk, uint16_t size);

#endif /* DRIVERS_UART_UART_H_ */
